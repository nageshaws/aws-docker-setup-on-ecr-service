const express = require("express");
const app = express();
app.get("/", (req,res)=>res.json({application:"Node.js API",status:"Running"}));
app.get("/health",(req,res)=>res.json({status:"UP"}));
app.listen(3000,"0.0.0.0");
